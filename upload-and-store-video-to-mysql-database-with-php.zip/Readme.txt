Author: Yogesh singh
Author URL: http://makitweb.com/
Author Email: yogesh@makitweb.com
Tutorial Link: http://makitweb.com/upload-and-store-video-to-mysql-database-with-php/

Instructions -

1. Import attached videos.sql in your database.
2. Update config.php file
3. Run index.php file to upload video files.
4. Run readvideos.php file to view uploaded video files.